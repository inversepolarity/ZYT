# Even Less Addictive YouTube
Remove some (more) elements from Youtube to make it less addictive. Mix and match between the following options:

- Hide or show thumbnails and video preview
- Hide or show recommended videos sidebar
- Hide or show comments
- Hide or show recommended videos end screen (when autoplay is off)
- Hide or show video preview on mouse over
- Hide or show end screen recommendations
- Hide or show community posts
- Hide or show ad thumbnails
- Hide or show feed filter chip bar
- More improvements in the works...

# Download
#### Chrome https://chrome.google.com/webstore/detail/less-addictive-youtube/olhmbgdbpfpkpejldoihajphhilpdnle
#### Firefox https://addons.mozilla.org/en-US/firefox/addon/less-addictive-youtube/

# Screenshots
![Remove comments and sidebar](https://github.com/JesseDrain/Less-Addictive-YouTube/blob/main/screenshots/removecommentsandsidebar1280x800.png)
![Remove thumbnails](https://github.com/JesseDrain/Less-Addictive-YouTube/blob/main/screenshots/GetRidOfThumbnails-1280x800.png)
