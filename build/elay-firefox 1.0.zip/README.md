# Even Less Addictive YouTube

Remove some ([more](https://github.com/AlexisDrain/Less-Addictive-YouTube)) elements from Youtube to make it less addictive. Mix and match between the following options:

- Hide or show thumbnails and video preview
- Hide or show recommended videos sidebar
- Hide or show comments
- Hide or show recommended videos end screen (when autoplay is off)
- Hide or show video preview on mouse over
- Hide or show end screen recommendations
- Hide or show community posts
- Hide or show ad thumbnails
- Hide or show feed filter chip bar
- More improvements in the works...